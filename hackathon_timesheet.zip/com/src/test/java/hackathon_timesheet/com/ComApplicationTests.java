package hackathon_timesheet.com;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComApplicationTests {

	@Test
	void contextLoads() {
	}

}
